
import numpy as np

# The program implements a single layer neural network classifier
# based on the numpy library, in this classifier, using the softmax function
# as the activation function.
class Classifier:

    def __init__(self):
        # w is the weight matrix of model, initialize as None
        self.w = None

    # This method converts the label y to one-hot encoding.
    def __one_hot_encoding(self, y):
        one_hot_y = np.zeros(shape=(len(y), 4))
        for i in range(0, len(y)): one_hot_y[i][y[i]] = 1
        return one_hot_y

    # The softmax activation function converts the input X into a probability.
    def __softmax(self, X):

        # The denominator, which is the sum of the terms.
        exp_sum = np.exp(X[0]).sum()
        result = np.exp(X[0]) / exp_sum
        for i in range(1, len(X)):
            exp_sum = np.exp(X[i]).sum()
            result = np.vstack((result, np.exp(X[i]) / exp_sum))
        return result

    # Compute the gradient of each element in the w.
    def __gradient(self, X, y_true, w):
        y_predict = self.__softmax(np.dot(X, w))

        # Error is a two-dimensional matrix that stores the error of each sample on each category
        error = y_predict - y_true
        grad = np.dot(X.T, error) / len(X)
        return grad

    # The training method uses batch gradient descent,
    # alpha is the learning rate, and the default iteration is 100 times.
    def __descent(self, X, y_true, alpha=0.01, n_iter=100):

        # Initialize w matrix, the shape is determined by X and y_true
        w = np.zeros(shape=(X.shape[1], y_true.shape[1]))
        for i in range(0, n_iter):
            grad = self.__gradient(X, y_true, w)
            # Update weight parameters
            w = w - alpha * grad
        return w

    def fit(self, data, target):

        # First convert the list object to numpy array
        X_train = np.array(data)
        y_train = np.array(target)

        # Integrate the bias into X_train, that is, the first column of matrix X_train is all 1.
        a = np.ones(shape=X_train.shape[0]).reshape(-1, 1)
        X_train = np.concatenate((a, X_train), axis=1)

        # Convert y_train to one-hot encoding
        y_train = self.__one_hot_encoding(y_train)

        # Apply gradient descent to get the weight w parameters of the classifier.
        self.w = self.__descent(X_train, y_train)

    def predict(self, data, legal=None):
        X_test = np.array(data)
        X_test = np.concatenate(([1], X_test))

        # Predict the direction of next move of pacman, select the direction with the highest probability
        return np.argmax(self.__softmax(np.dot(X_test, self.w)), axis=0)

    def reset(self):
        # reset w when the game is over
        self.w = None
        
